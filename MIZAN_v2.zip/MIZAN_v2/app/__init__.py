"""Bilingual Streamlit presentation layer."""
